/* ============================================================
   todos.js – Daily To‑Do list with drag‑and‑drop reordering
   ============================================================ */

App.Todos = (function(){
  "use strict";
  var U = App.Util;

  // ----- Render the list for the current day -----
  function renderTodos() {
    var container = document.getElementById("todo-list");
    if (!container) return;

    var d = App.Storage.getDay(App.curKey);
    var todos = d.todos || [];

    if (todos.length === 0) {
      container.innerHTML = '<div class="challenge-empty">No tasks for today. Add one below.</div>';
    } else {
      var html = '<div class="todo-items" id="todoItems">';
      todos.forEach(function(t, idx) {
        var doneClass = t.done ? 'done' : '';
        html +=
          '<div class="todo-row" draggable="true" data-id="' + t.id + '" data-index="' + idx + '">' +
            '<span class="todo-drag-handle" title="Drag to reorder">⠿</span>' +
            '<input type="checkbox" class="todo-check" data-id="' + t.id + '" ' + (t.done ? 'checked' : '') + '>' +
            '<span class="todo-text ' + doneClass + '">' + U.escapeHtml(t.text) + '</span>' +
            '<button class="todo-delete" data-id="' + t.id + '" aria-label="Delete task">✕</button>' +
          '</div>';
      });
      html += '</div>';
      html += '<div class="todo-actions"><button class="todo-clear-all danger">Clear all</button></div>';
      container.innerHTML = html;
      bindDragDrop();
    }
    updateTodoStats();
  }

  // ----- Update the stat card -----
  function updateTodoStats() {
    var d = App.Storage.getDay(App.curKey);
    var todos = d.todos || [];
    var done = todos.filter(function(t){ return t.done; }).length;
    var total = todos.length;
    var el = document.getElementById("sTodos");
    if (el) el.textContent = done + '/' + total;
  }

  // ----- Event wiring (delegation) -----
  function bindEvents() {
    var container = document.getElementById("todo-list");
    if (!container) return;

    // Toggle checkbox
    container.addEventListener('change', function(e) {
      var check = e.target.closest('.todo-check');
      if (check) toggleTodo(check.dataset.id);
    });

    // Delete button
    container.addEventListener('click', function(e) {
      var del = e.target.closest('.todo-delete');
      if (del) {
        e.preventDefault();
        deleteTodo(del.dataset.id);
        return;
      }
      var clear = e.target.closest('.todo-clear-all');
      if (clear) {
        e.preventDefault();
        clearTodos();
      }
    });

    // Add task
    var input = document.getElementById("todoInput");
    var addBtn = document.getElementById("todoAddBtn");
    if (input && addBtn) {
      addBtn.addEventListener('click', function() {
        addTodo(input.value);
      });
      input.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
          addTodo(input.value);
        }
      });
    }
  }

  // ----- Drag‑and‑drop reordering -----
  function bindDragDrop() {
    var items = document.querySelectorAll('.todo-row');
    var dragSrcIndex = null;

    items.forEach(function(item) {
      item.addEventListener('dragstart', function(e) {
        dragSrcIndex = parseInt(this.dataset.index);
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', this.dataset.id);
      });
      item.addEventListener('dragover', function(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
      });
      item.addEventListener('drop', function(e) {
        e.preventDefault();
        var targetIndex = parseInt(this.dataset.index);
        if (dragSrcIndex !== null && dragSrcIndex !== targetIndex) {
          reorderTodos(dragSrcIndex, targetIndex);
        }
        dragSrcIndex = null;
      });
      // Prevent drag from selecting text
      item.querySelector('.todo-drag-handle').addEventListener('mousedown', function(e) {
        e.preventDefault();
      });
    });
  }

  // ----- Data mutations (auto‑save) -----
  function getTodos() {
    var d = App.Storage.getDay(App.curKey);
    return d.todos || [];
  }

  function setTodos(todos) {
    App.Storage.mutateDay(App.curKey, function(d) {
      d.todos = todos;
    });
    renderTodos();
  }

  function addTodo(text) {
    text = text.trim();
    if (!text) return;
    var todos = getTodos();
    todos.push({ id: U.uid(), text: text, done: false });
    setTodos(todos);
    var input = document.getElementById("todoInput");
    if (input) input.value = '';
  }

  function toggleTodo(id) {
    var todos = getTodos();
    var found = false;
    todos = todos.map(function(t) {
      if (t.id === id) { t.done = !t.done; found = true; }
      return t;
    });
    if (found) setTodos(todos);
  }

  function deleteTodo(id) {
    var todos = getTodos();
    var newTodos = todos.filter(function(t) { return t.id !== id; });
    if (newTodos.length !== todos.length) setTodos(newTodos);
  }

  function clearTodos() {
    if (confirm('Remove all tasks for today?')) setTodos([]);
  }

  function reorderTodos(fromIndex, toIndex) {
    var todos = getTodos();
    if (fromIndex < 0 || fromIndex >= todos.length || toIndex < 0 || toIndex >= todos.length) return;
    var item = todos.splice(fromIndex, 1)[0];
    todos.splice(toIndex, 0, item);
    setTodos(todos);
  }

  // ----- Public API -----
  function init() {
    bindEvents();
  }

  return {
    init: init,
    renderTodos: renderTodos,
    updateTodoStats: updateTodoStats,
    addTodo: addTodo,
    toggleTodo: toggleTodo,
    deleteTodo: deleteTodo,
    clearTodos: clearTodos,
    reorderTodos: reorderTodos
  };
})();
