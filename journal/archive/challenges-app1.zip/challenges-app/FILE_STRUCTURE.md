# File Structure - Challenges App

Project: C:\Users\StudyAcer\OneDrive\Documents\Obsidian Vault\journal\challenges-app

Last Updated: 2026-06-26 11:27:23

---

challenges-app/
├── .agents/
├── .git/
├── archive/
│   ├── modular-refactor-2026-06-21/
│   │   ├── 21-day-challenge.html
│   │   ├── analytics.js
│   │   ├── app.js
│   │   ├── challenge.js
│   │   ├── habits.js
│   │   ├── index.html
│   │   ├── storage.js
│   │   └── theme.js
│   ├── previous-version/
│   ├── server-logs/
│   │   ├── php-server-8000.err.log
│   │   └── php-server-8000.out.log
│   └── trash/
├── assets/
│   ├── css/
│   │   ├── app.css
│   │   ├── dark-theme.css
│   │   ├── light-theme.css
│   │   └── variables.css
│   ├── icons/
│   └── js/
│       ├── analytics.js
│       ├── app.js
│       ├── challenge.js
│       ├── habits.js
│       ├── storage.js
│       ├── theme.js
│       └── todos.js
├── components/
│   ├── analytics-view.php
│   ├── challenge-view.php
│   ├── daily-view.php
│   ├── footer.php
│   ├── header.php
│   ├── navigation.php
│   └── todo-view.php
├── data/
│   └── backups/
│       └── june 24/
│           ├── 21-day-grid-2026-06-24.csv
│           ├── daily-log-2026-06-24.csv
│           └── tracker-backup-2026-06-24.json
├── tests/
│   └── smoke.js
├── agents.txt
├── FILE_STRUCTURE.md
├── improved_routine.md
├── index.php
├── README.md
├── readme.txt
└── start-challenges-app.bat

---

Legend:
  / = Directory
  (no symbol) = File
  ├── = Item with more below
  └── = Last item
