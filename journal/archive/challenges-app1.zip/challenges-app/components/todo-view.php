<div class="subpanel" id="sub-todos">
  <div class="sec-lbl">Today's To‑Do List</div>
  <div class="card" id="todo-list-container">
    <div id="todo-list"></div>
    <div class="todo-add-row">
      <input type="text" id="todoInput" placeholder="Add a task…" />
      <button type="button" id="todoAddBtn">Add</button>
    </div>
  </div>
</div>
